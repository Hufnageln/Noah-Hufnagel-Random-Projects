EULA:
Group M of engineering 1181 grants you unlimited, non-exclusive, transferabble, and irrevocable license to use 
Snake Game TM for your personal purposes. Have fun!

READ ME!
WOW! you actually read our fake EULA and README. 
That's prety cool! We hope you find this game enjoyable! Have a great time!