
/* internal header file for singly linked list */

typedef struct Node{
	struct Node *next;
	void *data;
	}Node;


